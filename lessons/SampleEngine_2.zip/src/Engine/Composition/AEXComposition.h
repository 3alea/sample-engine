#ifndef AEX_COMPOSITION_H_
#define AEX_COMPOSITION_H_

#include "AEXComponent.h"
#include "AEXGameObject.h"
#endif