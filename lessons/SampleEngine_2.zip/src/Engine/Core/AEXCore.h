#ifndef AEX_FOUNDATION_H_
#define AEX_FOUNDATION_H_

#include "AEXDataTypes.h"		// Data typedefs
#include "AEXRtti.h"			// Rtti
#include "AEXBase.h"			// Base object interface
#include "AEXSystem.h"			// Base system interface

#endif